// uio.c file:

YOUR printf() for printing %c %s %d %x %l, etc. BASED ON putc()